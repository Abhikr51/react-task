const Endpoints = {
    defaultData: '/data',
    test: '/todos'
}

export default Endpoints