import React from 'react'
import DataGridDisplay from '../components/DataGridDisplay'

export default function Home() {
  return (
    <div>
        <h1>
            Welcome to React Tasks
        </h1>
    </div>
  )
}
