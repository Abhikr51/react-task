import { SaltProviderNext } from '@salt-ds/core';
import '../styles.css';
import '@salt-ds/theme/index.css';
import '@salt-ds/theme/css/theme-next.css';

import { Navigation } from '../routes/Navigation';
import RouteGenerator from '../routes/RouteGenerator';
import ErrorPage from '../components/ErrorPage';
import { BrowserRouter } from 'react-router-dom';

// Define the new permission type
export interface RoutePermission {
  title: string;
  edit: boolean;
  view: boolean;
}

// Updated mocked permissions with the new structure
const mocked_permissions: RoutePermission[] = [
  {
    title: 'Dashboard',
    edit: true,
    view: true,
  },
  {
    title: 'Interventions.Overview',
    edit: false,
    view: true,
  },
  {
    title: 'Interventions.Stats',
    edit: true,
    view: true,
  },
  {
    title: 'Settings.Profile',
    edit: true,
    view: true,
  },
  // {
  //   title: 'DataProcessing',
  //   edit: true,
  //   view: true,
  // },
];

export function App() {
  return (
    <SaltProviderNext accent="teal" corner="rounded">
      <BrowserRouter>
        <div style={{ display: 'flex' }}>
          <Navigation userPermissions={mocked_permissions} />
          <div style={{ padding: '16px', flexGrow: 1 }}>
            <h1>Graphite App</h1>
            <RouteGenerator
              userPermissions={mocked_permissions}
              errorElement={<ErrorPage />}
            />
          </div>
        </div>
      </BrowserRouter>
    </SaltProviderNext>
  );
}

export default App;
