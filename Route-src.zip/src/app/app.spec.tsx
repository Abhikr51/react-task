import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import { App } from './app';

// Mock the SaltProviderNext component
jest.mock('@salt-ds/core', () => ({
  SaltProviderNext: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
}));

// Mock react-router-dom components
jest.mock('react-router-dom', () => ({
  BrowserRouter: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="browser-router">{children}</div>
  ),
}));

// Mock the Navigation component
jest.mock('../routes/Navigation', () => ({
  Navigation: ({
    userPermissions,
  }: {
    userPermissions: Array<{ title: string }>;
  }) => (
    <nav data-testid="navigation">
      {userPermissions.map((permission) => (
        <div
          key={permission.title}
          data-testid={`permission-${permission.title}`}
        >
          {permission.title}
        </div>
      ))}
    </nav>
  ),
}));

// Mock the RouteGenerator component
jest.mock('../routes/RouteGenerator', () => ({
  __esModule: true,
  default: ({
    userPermissions,
  }: {
    userPermissions: Array<{ title: string }>;
  }) => (
    <div data-testid="route-generator">
      {userPermissions.map((permission) => (
        <div key={permission.title} data-testid={`route-${permission.title}`}>
          {permission.title}
        </div>
      ))}
    </div>
  ),
}));

// Mock the ErrorPage component
jest.mock('../components/ErrorPage', () => ({
  __esModule: true,
  default: () => <div data-testid="error-page">Error Page</div>,
}));

describe('App Component', () => {
  it('renders without crashing', () => {
    render(<App />);
    expect(screen.getByText('Graphite App')).toBeInTheDocument();
  });

  it('renders the heading with correct text', () => {
    render(<App />);
    const headingElement = screen.getByRole('heading', { level: 1 });
    expect(headingElement).toHaveTextContent('Graphite App');
  });

  it('renders the Navigation component with correct permissions', () => {
    render(<App />);
    expect(screen.getByTestId('navigation')).toBeInTheDocument();
    expect(screen.getByTestId('permission-Dashboard')).toBeInTheDocument();
    expect(
      screen.getByTestId('permission-Interventions.Overview')
    ).toBeInTheDocument();
    expect(
      screen.getByTestId('permission-Interventions.Stats')
    ).toBeInTheDocument();
    expect(
      screen.getByTestId('permission-Settings.Profile')
    ).toBeInTheDocument();
  });

  it('renders the RouteGenerator component', () => {
    render(<App />);
    expect(screen.getByTestId('route-generator')).toBeInTheDocument();
    expect(screen.getByTestId('route-Dashboard')).toBeInTheDocument();
    expect(
      screen.getByTestId('route-Interventions.Overview')
    ).toBeInTheDocument();
    expect(screen.getByTestId('route-Interventions.Stats')).toBeInTheDocument();
    expect(screen.getByTestId('route-Settings.Profile')).toBeInTheDocument();
  });

  it('has the correct layout structure', () => {
    render(<App />);
    const routerElement = screen.getByTestId('browser-router');
    expect(routerElement).toBeInTheDocument();

    // Use type assertion to fix TypeScript errors
    const element: any = routerElement as Element;

    // Test that the router contains the main app content
    const heading = element.querySelector('h1');
    expect(heading).toHaveTextContent('Graphite App');

    const navigation = element.querySelector('[data-testid="navigation"]');
    expect(navigation).toBeInTheDocument();

    const routeGenerator = element.querySelector(
      '[data-testid="route-generator"]'
    );
    expect(routeGenerator).toBeInTheDocument();
  });
});
