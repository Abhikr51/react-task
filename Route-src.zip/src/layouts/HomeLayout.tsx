import React from 'react';
import { Outlet } from 'react-router-dom';

const HomeLayout: React.FC = () => {
  return (
    <div className="home-layout">
      <div className="home-content">
        {/* This is where nested routes will render */}
        <Outlet />
      </div>
    </div>
  );
};

export default HomeLayout;
