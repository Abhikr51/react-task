import React from 'react';
import { Outlet } from 'react-router-dom';

const SettingsLayout: React.FC = () => {
  return (
    <div className="settings-layout">
      <div className="settings-container">
        <div className="settings-content">
          {/* This is where nested routes will render */}
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default SettingsLayout;
