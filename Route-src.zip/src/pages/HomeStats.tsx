import React from 'react';

const HomeStats: React.FC = () => {
  return (
    <div className="p-4 bg-white rounded">
      <h3 className="text-xl font-medium mb-4">Statistics Dashboard</h3>
    </div>
  );
};

export default HomeStats;
