import { FC } from 'react';

interface ChildPageProps {
  title: string;
}

export const ChildPage: FC<ChildPageProps> = ({ title }) => {
  return (
    <div>
      <h3>{title}</h3>
    </div>
  );
};
