import React from 'react';

const Privacy: React.FC = () => {
  return (
    <div className="privacy-container">
      <h3>Privacy Settings</h3>
    </div>
  );
};

export default Privacy;
