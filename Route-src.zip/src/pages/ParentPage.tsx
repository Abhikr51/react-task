import { FC } from 'react';
import { Outlet } from 'react-router-dom';

interface ParentPageProps {
  title: string;
}

export const ParentPage: FC<ParentPageProps> = ({ title }) => {
  return (
    <div>
      <h2>{title}</h2>
      <Outlet />
    </div>
  );
};
