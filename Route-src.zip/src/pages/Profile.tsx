import React from 'react';

const Profile: React.FC = () => {
  return (
    <div className="p-4 bg-white rounded">
      <h3 className="text-xl font-medium mb-6">User Profile</h3>
    </div>
  );
};

export default Profile;
