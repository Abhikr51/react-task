import React from 'react';

const HomeOverview: React.FC = () => {
  return (
    <div className="p-6 bg-white rounded-lg shadow-sm my-2">
      <h3 className="text-2xl font-semibold text-gray-800 mb-6">
        Home Overview
      </h3>
      <div className="space-y-6">
        <p className="text-gray-600 max-w-3xl">
          Welcome to the overview page. This page provides a summary of your
          dashboard.
        </p>
      </div>
    </div>
  );
};

export default HomeOverview;
