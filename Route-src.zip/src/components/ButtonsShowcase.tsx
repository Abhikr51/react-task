import { FC } from 'react';
import { Button } from '@salt-ds/core';

export const ButtonsShowcase: FC = () => {
  return (
    <div style={{ marginTop: '24px' }}>
      <Button sentiment="accented" appearance="solid">
        Solid
      </Button>
      <Button sentiment="accented" appearance="bordered">
        Bordered
      </Button>
      <Button sentiment="accented" appearance="transparent">
        Transparent
      </Button>
    </div>
  );
};
