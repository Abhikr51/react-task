import React from 'react';
import { useRouteError, isRouteErrorResponse } from 'react-router-dom';

interface ErrorPageProps {
  error?: Error;
  resetErrorBoundary?: () => void;
}

const ErrorPage: React.FC<ErrorPageProps> = ({ error, resetErrorBoundary }) => {
  const routeError = useRouteError();

  // Determine what kind of error to display
  let errorMessage = 'An unexpected error occurred';
  let statusText = 'Error';

  if (error) {
    // Error from ErrorBoundary
    errorMessage = error.message || errorMessage;
  } else if (isRouteErrorResponse(routeError)) {
    // Error from React Router
    statusText = routeError.statusText;
    errorMessage =
      routeError.data?.message ||
      `${routeError.status} ${routeError.statusText}`;
  } else if (routeError instanceof Error) {
    errorMessage = routeError.message;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] p-6">
      <div className="bg-red-50 border border-red-100 rounded-lg p-6 max-w-lg w-full">
        <h2 className="text-xl text-red-700 font-semibold mb-3">
          {statusText}
        </h2>
        <p className="text-red-600 mb-4">{errorMessage}</p>
        <div className="flex gap-4">
          <button
            onClick={() => (window.location.href = '/dashboard')}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded"
          >
            Go to Dashboard
          </button>
          {resetErrorBoundary && (
            <button
              onClick={resetErrorBoundary}
              className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600 rounded"
            >
              Try Again
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ErrorPage;
