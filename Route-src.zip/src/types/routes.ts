import { ComponentType, LazyExoticComponent } from 'react';

export type InnerRoute = {
  title: string;
  path: string;
  component: LazyExoticComponent<ComponentType<any>>;
};

export type RouteConfig = {
  title: string;
  path: string;
  component: LazyExoticComponent<ComponentType<any>>;
  innerRoutes?: InnerRoute[];
};
