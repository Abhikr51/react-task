// Helper functions to check permissions
export const hasRouteAccess = (
  routeTitle: string,
  permissions: string[]
): boolean => {
  return permissions.some(
    (permission) =>
      permission.startsWith(`${routeTitle}.`) || permission === routeTitle
  );
};

export const hasInnerRouteAccess = (
  parentTitle: string,
  innerRouteTitle: string,
  permissions: string[]
): boolean => {
  return permissions.includes(`${parentTitle}.${innerRouteTitle}`);
};
