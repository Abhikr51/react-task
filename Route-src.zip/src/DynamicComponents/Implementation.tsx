import { DynamicComponentRenderer } from './index';
import {
  singaporeHeaderConfig,
  editableCheckboxConfig,
  appHeaderBarConfig,
  searchBarConfig,
  tabsConfig,
  testDataHeaderConfig,
  buttonConfig,
} from './config';
import { FlexItem, FlexLayout } from '@salt-ds/core';
// import { SearchIcon } from '@salt-ds/icons';
import * as SaltCore from '@salt-ds/core';
const Implementation = () => {
  //   const testArray = {
  //     Button,
  //   };
  const getComponent = (type: string) => {
    //@ts-ignore
    return SaltCore[type];
  };
  const Comp = getComponent('Button');
  return (
    <FlexLayout direction="column" gap={2}>
      <br />
      <FlexItem>
        {<DynamicComponentRenderer config={appHeaderBarConfig} />}
      </FlexItem>
      <FlexItem>
        {<DynamicComponentRenderer config={singaporeHeaderConfig} />}
      </FlexItem>
      <FlexItem>
        {<DynamicComponentRenderer config={editableCheckboxConfig} />}
      </FlexItem>
      <FlexItem>
        {<DynamicComponentRenderer config={searchBarConfig} />}
      </FlexItem>
      <FlexItem>{<DynamicComponentRenderer config={buttonConfig} />}</FlexItem>
      <FlexItem>{<DynamicComponentRenderer config={tabsConfig} />}</FlexItem>
      <FlexItem>
        {<DynamicComponentRenderer config={testDataHeaderConfig} />}
      </FlexItem>
      <Comp sentiment="accented" appearance="solid">
        Hello world
      </Comp>
    </FlexLayout>
  );
};

export default Implementation;
