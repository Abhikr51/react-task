export const singaporeHeaderConfig = {
  component: 'FlexLayout',
  lib: 'core',
  props: {
    direction: 'row',
    align: 'center',
    style: {
      background: '#15313b',
      padding: '0.5rem 1rem',
      color: '#fff',
      fontFamily: 'inherit',
      fontSize: '1.2rem',
      height: '48px',
      gap: '1rem',
      width: 'fit-content',
    },
  },
  children: [
    {
      component: 'FlexItem',
      lib: 'core',
      props: {
        style: {
          display: 'flex',
          alignItems: 'center',
          marginRight: '0.75rem',
          fontWeight: 300,
          cursor: 'pointer',
          userSelect: 'none',
        },
        'aria-label': 'Back',
      },
    },
    {
      component: 'span',
      lib: 'html',
      props: {
        style: {
          fontWeight: 'bold',
          fontSize: '1.1rem',
          marginRight: '1.2rem',
        },
      },
      children: ['Singapore'],
    },
    {
      component: 'span',
      lib: 'html',
      props: {
        style: {
          color: '#f48b82',
          fontWeight: 500,
          fontSize: '1.1rem',
          marginLeft: '0.2rem',
          letterSpacing: '0.01em',
          display: 'flex',
          alignItems: 'center',
          gap: '0.25rem',
        },
      },
      children: [
        {
          component: 'ChevronUpIcon',
          lib: 'icon',
          props: {
            style: {
              fontSize: '1rem',
              color: '#f48b82',
              verticalAlign: 'middle',
            },
          },
        },
        '00:00:00 10:50 EST',
      ],
    },
  ],
};

export const editableCheckboxConfig = {
  component: 'FlexLayout',
  lib: 'core',
  props: {
    direction: 'row',
    align: 'center',
    gap: '2.5rem',
    style: {
      background: '#f7f9fa',
      padding: '2rem',
      width: 'fit-content',
    },
  },
  children: [
    {
      component: 'FlexItem',
      lib: 'core',
      props: {
        style: { display: 'flex', alignItems: 'center', gap: '0.5rem' },
      },
      children: [
        {
          component: 'Checkbox',
          lib: 'core',
          props: {},
          children: [],
        },
        {
          component: 'span',
          lib: 'html',
          props: { style: { fontSize: '1.1rem' } },
          children: ['Editable (20)'],
        },
      ],
    },
    {
      component: 'FlexItem',
      lib: 'core',
      props: {
        style: { display: 'flex', alignItems: 'center', gap: '0.5rem' },
      },
      children: [
        {
          component: 'Checkbox',
          lib: 'core',
          props: {},
          children: [],
        },
        {
          component: 'span',
          lib: 'html',
          props: { style: { fontSize: '1.1rem' } },
          children: ['Non-Editable (10)'],
        },
      ],
    },
  ],
};

export const appHeaderBarConfig = {
  component: 'header',
  lib: 'html',
  props: {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: '#071a24',
      padding: '0 2.5rem',
      height: '56px',
      color: '#fff',
      fontWeight: 700,
      fontSize: '1.5rem',
    },
  },
  children: [
    {
      component: 'div',
      lib: 'html',
      props: {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: '2.5rem',
        },
      },
      children: [
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontWeight: 'bold',
              fontSize: '1.5rem',
              letterSpacing: '0.02em',
            },
          },
          children: ['J.P Morgan'],
        },
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontWeight: 'bold',
              fontSize: '1.5rem',
              margin: '0 2.5rem',
              letterSpacing: '0.02em',
            },
          },
          children: ['|'],
        },
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontWeight: 'bold',
              fontSize: '1.5rem',
              letterSpacing: '0.02em',
            },
          },
          children: ['Graphite'],
        },
      ],
    },
    {
      component: 'div',
      lib: 'html',
      props: {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: '2rem',
        },
      },
      children: [
        {
          component: 'NotificationIcon',
          lib: 'icon',
          props: {
            style: {
              fontSize: '1.5rem',
              color: '#fff',
              verticalAlign: 'middle',
            },
          },
        },
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontSize: '1rem',
              fontWeight: 400,
              marginRight: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
            },
          },
          children: ['Request center'],
        },
        {
          component: 'BuildingIcon',
          lib: 'icon',
          props: {
            style: {
              fontSize: '1.5rem',
              color: '#fff',
              verticalAlign: 'middle',
            },
          },
        },
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontSize: '1rem',
              fontWeight: 400,
              marginRight: '1.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
            },
          },
          children: ['Demo Center'],
        },
        {
          component: 'div',
          lib: 'html',
          props: {
            style: {
              width: '2.2rem',
              height: '2.2rem',
              borderRadius: '50%',
              background: '#b75e1c',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '1.2rem',
              marginRight: '1.2rem',
            },
          },
          children: ['M'],
        },
        {
          component: 'span',
          lib: 'html',
          props: {
            style: {
              fontWeight: 500,
              fontSize: '1.1rem',
              marginRight: '0.5rem',
            },
          },
          children: ['Martin'],
        },
        {
          component: 'MicroMenuIcon',
          lib: 'icon',
          props: {
            style: {
              fontSize: '1.5rem',
              color: '#fff',
              verticalAlign: 'middle',
            },
          },
        },
      ],
    },
  ],
};

export const searchBarConfig = {
  component: 'FlexItem',
  lib: 'core',
  children: [
    {
      component: 'Input',
      lib: 'core',
      props: {
        startAdornment: {
          component: 'SearchIcon',
          lib: 'icon',
        },
        inputProps: {
          placeholder: 'Search',
          'aria-label': 'Search',
        },
      },
      children: ['Hello world'],
    },
  ],
};
export const buttonConfig = {
  component: 'FlexItem',
  lib: 'core',
  children: [
    {
      component: 'Button',
      props: {
        sentiment: 'accented',
        appearance: 'solid',
      },
      lib: 'core',
      children: ['Hello world'],
    },
  ],
};

export const tabsConfig = {
  component: 'StackLayout',
  lib: 'core',
  props: {},
  children: [
    {
      component: 'TabsNext',
      lib: 'lab',
      props: { defaultValue: 'Home' },
      children: [
        {
          component: 'TabBar',
          lib: 'lab',
          props: {},
          children: [
            {
              component: 'TabListNext',
              lib: 'lab',
              props: { appearance: 'transparent' },
              children: [
                {
                  component: 'TabNext',
                  lib: 'lab',
                  props: { value: 'Home' },
                  children: [
                    {
                      component: 'TabNextTrigger',
                      lib: 'lab',
                      props: {},
                      children: ['Home'],
                    },
                  ],
                },
                {
                  component: 'TabNext',
                  lib: 'lab',
                  props: { value: 'Transactions' },
                  children: [
                    {
                      component: 'TabNextTrigger',
                      lib: 'lab',
                      props: {},
                      children: ['Transactions'],
                    },
                  ],
                },
                {
                  component: 'TabNext',
                  lib: 'lab',
                  props: { value: 'Loans' },
                  children: [
                    {
                      component: 'TabNextTrigger',
                      lib: 'lab',
                      props: {},
                      children: ['Loans'],
                    },
                  ],
                },
                {
                  component: 'TabNext',
                  lib: 'lab',
                  props: { value: 'Checks' },
                  children: [
                    {
                      component: 'TabNextTrigger',
                      lib: 'lab',
                      props: {},
                      children: ['Checks'],
                    },
                  ],
                },
                {
                  component: 'TabNext',
                  lib: 'lab',
                  props: { value: 'Liquidity' },
                  children: [
                    {
                      component: 'TabNextTrigger',
                      lib: 'lab',
                      props: {},
                      children: ['Liquidity'],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};

export const testDataHeaderConfig = {
  component: 'FlexLayout',
  lib: 'core',
  props: {
    direction: 'row',
    align: 'center',
    justify: 'space-between',
    style: {
      width: '100%',
      padding: '0.5rem 0 0 0',
      borderBottom: '1px solid #bbb',
      marginBottom: '0.5rem',
    },
  },
  children: [
    {
      component: 'span',
      lib: 'html',
      props: {
        style: {
          fontSize: '1.2rem',
          fontWeight: 400,
          marginLeft: '0.5rem',
        },
      },
      children: ['Test Data'],
    },
    {
      component: 'FlexLayout',
      lib: 'core',
      props: {
        direction: 'row',
        align: 'center',
        gap: '1.5rem',
        className: 'p-4',
      },
      children: [
        {
          component: 'FlexItem',
          lib: 'core',
          children: [
            {
              component: 'EditIcon',
              lib: 'icon',
            },
          ],
        },
        {
          component: 'FlexItem',
          lib: 'core',
          children: [
            {
              component: 'FavoriteIcon',
              lib: 'icon',
            },
          ],
        },
        {
          component: 'FlexItem',
          lib: 'core',
          children: [
            {
              component: 'Divider',
              lib: 'core',
            },
          ],
        },
      ],
    },
  ],
};
