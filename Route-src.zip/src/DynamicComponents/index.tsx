import React, { useMemo } from 'react';
import * as SaltCore from '@salt-ds/core';
import * as SaltIcons from '@salt-ds/icons';
import * as SaltLab from '@salt-ds/lab';
type DynamicComponentConfig = {
  component: string;
  lib: string;
  props?: Record<string, any>;
  children?: Array<string | DynamicComponentConfig>;
};

const getComponent = (
  type: string,
  lib: string
): React.ElementType | undefined => {
  if (lib === 'core') return (SaltCore as any)[type];
  if (lib === 'lab') return (SaltLab as any)[type];
  if (lib === 'icon') return (SaltIcons as any)[type];
  // For html, return undefined and handle in renderer
  return undefined;
};

type DynamicComponentRendererProps = {
  config: DynamicComponentConfig;
};

const DynamicComponentRendererInner = ({
  config,
}: DynamicComponentRendererProps): React.ReactNode => {
  const { component, lib, props = {}, children = [] } = config;

  // Memoize component lookup (skip for html)
  const Comp = useMemo(
    () => (lib !== 'html' ? getComponent(component, lib) : undefined),
    [component, lib]
  );

  // Avoid mutating original props
  const resolvedProps = useMemo(() => {
    const clonedProps = { ...props };
    Object.keys(clonedProps).forEach((key) => {
      const value = clonedProps[key];
      if (
        value &&
        typeof value === 'object' &&
        value.component &&
        value.lib // treat as DynamicComponentConfig
      ) {
        clonedProps[key] = <DynamicComponentRenderer config={value} />;
      }
    });
    return clonedProps;
  }, [props]);

  // Memoize children resolution
  const resolvedChildren = useMemo(() => {
    if (!children.length) return undefined;
    return children.map((child, idx) =>
      typeof child === 'string' ? (
        child
      ) : (
        <React.Fragment key={idx}>
          <DynamicComponentRenderer config={child} />
        </React.Fragment>
      )
    );
  }, [children]);

  if (lib === 'html') {
    return React.createElement(component, resolvedProps, resolvedChildren);
  }

  if (!Comp) {
    return (
      <div>
        Unknown component: {component} ({lib})
      </div>
    );
  }

  return <Comp {...resolvedProps}>{resolvedChildren}</Comp>;
};

// Memoize the renderer to avoid unnecessary re-renders
export const DynamicComponentRenderer = React.memo(
  DynamicComponentRendererInner
);
