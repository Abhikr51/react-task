import { lazy } from 'react';
import { RouteConfig } from '../types/routes';

// Lazy load components for code splitting
const HomeOverview = lazy(() => import('../pages/HomeOverview'));
const HomeStats = lazy(() => import('../pages/HomeStats'));
const Profile = lazy(() => import('../pages/Profile'));
const Privacy = lazy(() => import('../pages/Privacy'));
const HomeLayout = lazy(() => import('../layouts/HomeLayout'));
const SettingsLayout = lazy(() => import('../layouts/SettingsLayout'));
const DataProcessing = lazy(() => import('../pages/DataProcessing'));
const Dashboard = lazy(() => import('../pages/Dashboard'));

// Define route data with explicit inner route structure
const routes: RouteConfig[] = [
  {
    title: 'Dashboard',
    path: '/dashboard',
    component: Dashboard,
  },
  {
    title: 'Interventions',
    path: '/interventions',
    component: HomeLayout,
    innerRoutes: [
      {
        title: 'Overview',
        path: '/interventions/overview',
        component: HomeOverview,
      },
      {
        title: 'Stats',
        path: '/interventions/stats',
        component: HomeStats,
      },
    ],
  },
  {
    title: 'Settings',
    path: '/settings',
    component: SettingsLayout,
    innerRoutes: [
      {
        title: 'Profile',
        path: '/settings/profile',
        component: Profile,
      },
      {
        title: 'Privacy',
        path: '/settings/privacy',
        component: Privacy,
      },
    ],
  },
  // New route with no inner routes - innerRoutes property removed since it's optional
  {
    title: 'DataProcessing',
    path: '/data-processing',
    component: DataProcessing,
  },
];

export default routes;
