import { FC, Suspense, ReactElement } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import routes from '.';
import { RoutePermission } from '../app/app';
import ProtectedRoute from './ProtectedRoutes';
import NotFoundPage from '../pages/NotFoundPage';

// Helper functions for checking permissions (same as in Navigation)
const hasRouteAccess = (
  routeTitle: string,
  permissions: RoutePermission[]
): boolean => {
  return permissions.some(
    (permission) =>
      (permission.title === routeTitle && permission.view) ||
      (permission.title.startsWith(`${routeTitle}.`) && permission.view)
  );
};

const hasInnerRouteAccess = (
  parentTitle: string,
  innerRouteTitle: string,
  permissions: RoutePermission[]
): boolean => {
  const fullPath = `${parentTitle}.${innerRouteTitle}`;
  const permission = permissions.find((p) => p.title === fullPath);
  return permission ? permission.view : false;
};

// Function to get permissions for a specific route
const getRoutePermissions = (
  routeTitle: string,
  permissions: RoutePermission[]
) => {
  const permission = permissions.find((p) => p.title === routeTitle);
  return {
    canEdit: permission ? permission.edit : false,
    canView: permission ? permission.view : false,
  };
};

// Function to get permission props directly without renaming
const getPermissionProps = (
  routeTitle: string,
  permissions: RoutePermission[]
) => {
  const permission = permissions.find((p) => p.title === routeTitle);
  if (!permission) return {};

  // Create a copy of the permission object without the title property
  const { title, ...permissionProps } = permission;
  return permissionProps;
};

interface RouteGeneratorProps {
  userPermissions: RoutePermission[];
  errorElement?: ReactElement; // Added errorElement prop
}

const RouteGenerator: FC<RouteGeneratorProps> = ({
  userPermissions,
  errorElement,
}) => {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Routes>
        <Route
          path="/"
          element={<Navigate to="/dashboard" replace />}
          errorElement={errorElement}
        />

        {routes.map((route) => {
          const RouteComponent = route.component;
          const hasAccess = hasRouteAccess(route.title, userPermissions);

          // If no innerRoutes defined, render the component directly (no layout with outlet)
          if (!route.innerRoutes || route.innerRoutes.length === 0) {
            return (
              <Route
                key={route.path}
                path={route.path}
                errorElement={errorElement}
                element={
                  hasAccess ? (
                    <ProtectedRoute
                      element={<RouteComponent />}
                      hasPermission={hasAccess}
                      permissionProps={getPermissionProps(
                        route.title,
                        userPermissions
                      )}
                    />
                  ) : (
                    <Navigate to="/dashboard" replace />
                  )
                }
              />
            );
          }

          // Otherwise, render with nested routes using the layout component
          return (
            <Route
              key={route.path}
              path={route.path}
              errorElement={errorElement} // Error element defined at parent route level
              element={
                hasAccess ? (
                  <ProtectedRoute
                    element={<RouteComponent />}
                    hasPermission={hasAccess}
                    permissionProps={getPermissionProps(
                      route.title,
                      userPermissions
                    )}
                  />
                ) : (
                  <Navigate to="/dashboard" replace />
                )
              }
            >
              <Route index element={<div>Select a sub-section</div>} />
              {route.innerRoutes.map((innerRoute) => {
                const nestedPath = innerRoute.path.split('/').pop() || '';
                const InnerRouteComponent = innerRoute.component;
                const fullPath = `${route.title}.${innerRoute.title}`;
                const { canEdit: innerCanEdit, canView: innerCanView } =
                  getRoutePermissions(fullPath, userPermissions);
                const hasInnerAccess = hasInnerRouteAccess(
                  route.title,
                  innerRoute.title,
                  userPermissions
                );

                return (
                  <Route
                    key={innerRoute.path}
                    path={nestedPath}
                    element={
                      hasInnerAccess ? (
                        <InnerRouteComponent
                          canEdit={innerCanEdit}
                          canView={innerCanView}
                        />
                      ) : (
                        <Navigate to={route.path} replace />
                      )
                    }
                    // No need to specify errorElement here - errors will bubble up to parent
                  />
                );
              })}
            </Route>
          );
        })}

        {/* Catch-all route for 404 pages - must be placed after all other routes */}
        <Route
          path="*"
          element={<NotFoundPage />}
          errorElement={errorElement}
        />
      </Routes>
    </Suspense>
  );
};

export default RouteGenerator;
