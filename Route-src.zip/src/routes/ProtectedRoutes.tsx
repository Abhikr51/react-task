import React, { FC, ReactElement } from 'react';
import { Navigate, useLocation } from 'react-router-dom';

// Update props interface to accept any permission properties
interface ProtectedRouteProps {
  element: ReactElement;
  hasPermission: boolean;
  permissionProps?: Record<string, any>; // Accept any permission properties
}

const ProtectedRoute: FC<ProtectedRouteProps> = ({
  element,
  hasPermission,
  permissionProps = {},
}) => {
  const location = useLocation();

  if (!hasPermission) {
    return <Navigate to="/dashboard" state={{ from: location }} replace />;
  }

  // Pass all permission properties directly without renaming
  return React.cloneElement(element, permissionProps);
};

export default ProtectedRoute;
