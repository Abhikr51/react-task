import { FC } from 'react';
import { NavLink } from 'react-router-dom';
import routes from '.';
import { RoutePermission } from '../app/app';

// Define props with the new permission structure
interface NavigationProps {
  userPermissions: RoutePermission[];
}

// Updated helper functions to check permissions with the new structure
const hasRouteAccess = (
  routeTitle: string,
  permissions: RoutePermission[]
): boolean => {
  // Check if the user has at least view permission for the route
  return permissions.some(
    (permission) =>
      (permission.title === routeTitle && permission.view) ||
      (permission.title.startsWith(`${routeTitle}.`) && permission.view)
  );
};

const hasInnerRouteAccess = (
  parentTitle: string,
  innerRouteTitle: string,
  permissions: RoutePermission[]
): boolean => {
  // Check if user has view permission for this specific inner route
  const fullPath = `${parentTitle}.${innerRouteTitle}`;
  const permission = permissions.find((p) => p.title === fullPath);
  return permission ? permission.view : false;
};

export const Navigation: FC<NavigationProps> = ({ userPermissions }) => {
  return (
    <>
      <br />
      <DummyNavigation userPermissions={userPermissions} />
    </>
  );
};

const DummyNavigation: FC<any> = ({ userPermissions }) => {
  return (
    <nav
      style={{
        padding: '16px',
        borderRight: '1px solid #ccc',
        minWidth: '200px',
      }}
    >
      {routes.map((route) => {
        // Only show routes the user has access to
        if (!hasRouteAccess(route.title, userPermissions)) return null;

        return (
          <div key={route.path} style={{ marginBottom: '16px' }}>
            <NavLink
              to={route.path}
              style={({ isActive }) => ({
                fontWeight: isActive ? 'bold' : 'normal',
                textDecoration: 'none',
                color: 'inherit',
              })}
            >
              {route.title}
            </NavLink>

            {/* Only render inner routes section if innerRoutes exists and has items */}
            {route.innerRoutes && route.innerRoutes.length > 0 && (
              <div style={{ marginLeft: '16px', marginTop: '8px' }}>
                {route.innerRoutes.map((innerRoute) => {
                  // Only show inner routes the user has access to
                  if (
                    !hasInnerRouteAccess(
                      route.title,
                      innerRoute.title,
                      userPermissions
                    )
                  )
                    return null;

                  return (
                    <div key={innerRoute.path} style={{ marginBottom: '8px' }}>
                      <NavLink
                        to={innerRoute.path}
                        style={({ isActive }) => ({
                          fontWeight: isActive ? 'bold' : 'normal',
                          textDecoration: 'none',
                          color: 'inherit',
                        })}
                      >
                        {innerRoute.title}
                      </NavLink>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </nav>
  );
};
